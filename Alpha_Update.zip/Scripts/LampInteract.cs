using UnityEngine;

public class LampInteract : MonoBehaviour
{
    public Light lampLight;
    public GameObject lampClue;

    public void Click()
    {
        lampLight.enabled = !lampLight.enabled;

        if (lampLight.enabled)
        {
            lampClue.SetActive(true);
        }

        Debug.Log("Lamp clicked!");
    }
}