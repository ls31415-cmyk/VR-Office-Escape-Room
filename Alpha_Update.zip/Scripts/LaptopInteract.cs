using UnityEngine;

public class LaptopInteract : MonoBehaviour
{
    public GameObject codeClue;

    private bool clueShown = false;

    public void Click()
    {
        if (!clueShown)
        {
            codeClue.SetActive(true);
            clueShown = true;
            Debug.Log("Code revealed: 2847");
        }
    }
}