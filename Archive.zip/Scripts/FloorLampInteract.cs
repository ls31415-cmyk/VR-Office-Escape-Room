using UnityEngine;

public class FloorLampInteract : MonoBehaviour
{
    public Light lampLight;
    private bool isOn = true;

    public void Click()
    {
        isOn = !isOn;
        lampLight.enabled = isOn;
        Debug.Log("Floor lamp clicked!");
    }
}