using UnityEngine;

public class LampInteract : MonoBehaviour
{
    public Light lampLight;

    public void Click()
    {
        lampLight.enabled = !lampLight.enabled;
        Debug.Log("Lamp clicked!");
    }
}