using UnityEngine;

public class LaptopInteract : MonoBehaviour
{
    private bool open = false;

    public void Click()
    {
        open = !open;

        if (open)
        {
            transform.Rotate(0f, 20f, 0f);
        }
        else
        {
            transform.Rotate(0f, -20f, 0f);
        }

        Debug.Log("Laptop clicked!");
    }
}