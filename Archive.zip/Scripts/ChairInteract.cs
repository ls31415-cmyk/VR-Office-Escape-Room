using UnityEngine;

public class ChairInteract : MonoBehaviour
{
    private bool rotated = false;
    private Quaternion originalRotation;
    private Quaternion rotatedRotation;

    void Start()
    {
        originalRotation = transform.rotation;
        rotatedRotation = Quaternion.Euler(
            transform.eulerAngles.x,
            transform.eulerAngles.y + 25f,
            transform.eulerAngles.z
        );
    }

    public void Click()
    {
        rotated = !rotated;
        transform.rotation = rotated ? rotatedRotation : originalRotation;
        Debug.Log("Chair clicked!");
    }
}