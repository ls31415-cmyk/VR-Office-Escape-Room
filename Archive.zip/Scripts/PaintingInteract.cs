using UnityEngine;

public class PaintingInteract : MonoBehaviour
{
    private bool zoomed = false;
    private Vector3 originalScale;
    private Vector3 zoomScale;

    void Start()
    {
        originalScale = transform.localScale;
        zoomScale = originalScale * 1.15f;
    }

    public void Click()
    {
        zoomed = !zoomed;
        transform.localScale = zoomed ? zoomScale : originalScale;
        Debug.Log("Painting clicked!");
    }
}